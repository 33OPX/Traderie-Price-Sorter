// background.js (can be left empty or used for future enhancements)
